
// ملف script.js
const cartItems = [];
const cartList = document.querySelector('.cart-items');
const totalElement = document.querySelector('.total');

document.querySelectorAll('.add-to-cart').forEach(button => {
  button.addEventListener('click', () => {
    const name = button.getAttribute('data-name');
    const price = parseFloat(button.getAttribute('data-price'));
    cartItems.push({ name, price });

    updateCart();
  });
});

function updateCart() {
  cartList.innerHTML = '';
  let total = 0;

  cartItems.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.name} - ${item.price} درهم`;
    cartList.appendChild(li);
    total += item.price;
  });

  totalElement.textContent = `الإجمالي: ${total} درهم`;
}
